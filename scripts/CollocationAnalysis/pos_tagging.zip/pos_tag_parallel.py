# Stephan Raaijmakers, May 2025
import spacy
import os
from concurrent.futures import ProcessPoolExecutor, as_completed
import time
import argparse

import json

def json2text(json_data):
    data_dict = None
    if isinstance(json_data, str):
        try:
            data_dict = json.loads(json_data)
        except json.JSONDecodeError:
            print("Error: Invalid JSON string provided.")
            return None
    elif isinstance(json_data, dict):
        data_dict = json_data
    else:
        print("Error: Input must be a dictionary or a JSON formatted string.")
        return None
    
    data_dict=data_dict[0]
    
    if data_dict and "text" in data_dict:
        
        return data_dict["text"]
    else:
        return ""





def process_and_save_tags(input_file_path, output_file_path, spacy_model_name="en_core_web_sm"):
    """
    Loads a spaCy model, reads an input text file, performs POS tagging,
    and saves the (token, POS_tag) pairs to an output file.
    Disables 'parser' and 'ner' for faster POS tagging if they are not needed.
    """
    print(f"Processing file: {input_file_path} in process {os.getpid()}")
    try:
        nlp = spacy.load(spacy_model_name, disable=["parser", "ner"])
    except OSError:
        return input_file_path, False, f"Spacy model '{spacy_model_name}' not found. Please download it (e.g., python -m spacy download {spacy_model_name})."

    try:
        with open(input_file_path, 'r', encoding='utf-8') as f_in:
            text_content = json2text(f_in.read()) # assume json files 
    except Exception as e:
        return input_file_path, False, f"Error reading input file: {e}"

    if not text_content.strip():
        try:
            with open(output_file_path, 'w', encoding='utf-8') as f_out:
                pass # Create empty file
            return input_file_path, True, "Input file was empty or contained only whitespace. Empty output file created."
        except Exception as e:
            return input_file_path, False, f"Input file empty, error creating empty output file: {e}"

    doc = nlp(text_content)

    try:
        with open(output_file_path, 'w', encoding='utf-8') as f_out:
            for token in doc:
                f_out.write(f"{token.text}\t{token.pos_}\n")
        return input_file_path, True, None # file_path, success_status, error_message
    except Exception as e:
        return input_file_path, False, f"Error writing output file: {e}"

def batch_pos_tag_parallel_to_files(input_folder_path, spacy_model_name="en_core_web_sm", file_extension=".json", num_workers=None):
    if not os.path.isdir(input_folder_path):
        print(f"Error: Input folder not found at '{input_folder_path}'")
        return

    file_tasks = []
    for fname in os.listdir(input_folder_path):
        if os.path.isfile(os.path.join(input_folder_path, fname)) and fname.endswith(file_extension):
            input_file = os.path.join(input_folder_path, fname)
            output_file = os.path.join(input_folder_path, fname + ".pos_tagged")
            file_tasks.append((input_file, output_file))

    if not file_tasks:
        print(f"No '{file_extension}' files found in '{input_folder_path}'")
        return

    if num_workers is None:
        num_workers = os.cpu_count()
        if num_workers is None:
            num_workers = 2
        print(f"Using default number of workers: {num_workers} (number of CPU cores or 2 if undetermined)")
    else:
        print(f"Using specified number of workers: {num_workers}")

    print(f"Starting POS tagging for {len(file_tasks)} files using spaCy model '{spacy_model_name}'...")
    overall_start_time = time.time()

    success_count = 0
    failure_count = 0

    with ProcessPoolExecutor(max_workers=num_workers) as executor:
        future_to_task = {
            executor.submit(process_and_save_tags, task[0], task[1], spacy_model_name): task
            for task in file_tasks
        }

        for i, future in enumerate(as_completed(future_to_task)):
            original_input_file, _ = future_to_task[future]
            try:
                _, success, error_msg = future.result()
                if success:
                    success_count += 1
                    if error_msg: # e.g. empty file message
                        print(f"\nProcessed (with note): {original_input_file} -> {error_msg}")
                else:
                    failure_count += 1
                    print(f"\nFailed to process {original_input_file}: {error_msg}")
            except Exception as exc:
                failure_count += 1
                print(f"\nAn exception occurred while processing task for {original_input_file}: {exc}")

            print(f"Progress: {i + 1}/{len(file_tasks)} files. Success: {success_count}, Failed: {failure_count}", end='\r')

    print(f"\n\nPOS tagging complete.")
    print(f"Successfully processed: {success_count} files.")
    print(f"Failed to process: {failure_count} files.")
    overall_end_time = time.time()
    print(f"Total time taken: {overall_end_time - overall_start_time:.2f} seconds.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Perform Part-of-Speech tagging on text files in a folder using spaCy in parallel, saving output to .pos_tagged files.")
    parser.add_argument("--input", dest="input_folder", help="Path to the folder containing text files.")
    parser.add_argument("--model", default="en_core_web_sm", help="Name of the spaCy model to use (e.g., en_core_web_sm, en_core_web_md).")
    parser.add_argument("--ext", default=".txt", help="File extension of text files to process (e.g., .txt, .text).")
    parser.add_argument("--workers", type=int, help="Number of worker processes to use (defaults to CPU count).")

    args = parser.parse_args()


    batch_pos_tag_parallel_to_files(
        args.input_folder,
        spacy_model_name=args.model,
        file_extension=args.ext,
        num_workers=args.workers
    )